<?php

namespace Krlove\EloquentModelGenerator\Model;

/**
 * Class HasMany
 * @package Krlove\EloquentModelGenerator\Model
 */
class HasMany extends Relation
{
}
