<?php

namespace Krlove\EloquentModelGenerator\Exception;

/**
 * Class GeneratorException
 * @package Krlove\EloquentModelGenerator\Exception
 */
class GeneratorException extends \Exception
{
}
