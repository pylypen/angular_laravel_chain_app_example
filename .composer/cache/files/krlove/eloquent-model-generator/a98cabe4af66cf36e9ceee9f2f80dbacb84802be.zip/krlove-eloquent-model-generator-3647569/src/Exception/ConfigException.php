<?php

namespace Krlove\EloquentModelGenerator\Exception;

/**
 * Class ConfigException
 * @package Krlove\EloquentModelGenerator\Exception
 */
class ConfigException extends \Exception
{
}
