<?php

namespace Krlove\EloquentModelGenerator\Model;

/**
 * Class HasOne
 * @package Krlove\EloquentModelGenerator\Model
 */
class HasOne extends Relation
{
}
