<?php

namespace Krlove\CodeGenerator\Exception;

/**
 * Class ValidationException
 * @package Krlove\CodeGenerator\Exception
 */
class ValidationException extends \Exception
{
}