<?php

namespace Krlove\CodeGenerator\Exception;

/**
 * Class GeneratorException
 * @package Krlove\CodeGenerator\Exception
 */
class GeneratorException extends \Exception
{
}
