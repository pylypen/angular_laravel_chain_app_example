<?php namespace Rollbar\TestHelpers\Exceptions;

class FiftyFiftyExceptionSampleRate extends \Exception
{
}
