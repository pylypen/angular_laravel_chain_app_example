<?php namespace Rollbar\TestHelpers\Exceptions;

class VerboseExceptionSampleRate extends MidExceptionSampleRate
{
}
