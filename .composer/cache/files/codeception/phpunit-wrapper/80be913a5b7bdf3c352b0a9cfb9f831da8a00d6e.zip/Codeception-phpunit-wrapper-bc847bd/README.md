# PHPUnit Wrapper

Builds:

* 6.0 [![Build Status](https://travis-ci.org/Codeception/phpunit-wrapper.svg?branch=6.0)](https://travis-ci.org/Codeception/phpunit-wrapper)
* 7.0 [![Build Status](https://travis-ci.org/Codeception/phpunit-wrapper.svg?branch=7.0)](https://travis-ci.org/Codeception/phpunit-wrapper)

Codeception heavily relies on PHPUnit for running and managing tests.
Not all PHPUnit classes fit the needs of Codeception, that's why they were extended or redefined.

Releases follow major PHPUnit versions. 
