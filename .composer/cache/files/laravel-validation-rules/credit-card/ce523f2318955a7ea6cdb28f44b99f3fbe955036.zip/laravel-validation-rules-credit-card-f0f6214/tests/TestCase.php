<?php

namespace LVR\CreditCard\Tests;

class TestCase extends \Orchestra\Testbench\TestCase
{
}
