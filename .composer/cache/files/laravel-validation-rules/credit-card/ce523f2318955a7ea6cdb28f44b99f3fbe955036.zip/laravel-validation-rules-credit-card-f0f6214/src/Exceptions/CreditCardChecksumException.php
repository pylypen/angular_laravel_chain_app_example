<?php

namespace LVR\CreditCard\Exceptions;

class CreditCardChecksumException extends CreditCardException
{
}
