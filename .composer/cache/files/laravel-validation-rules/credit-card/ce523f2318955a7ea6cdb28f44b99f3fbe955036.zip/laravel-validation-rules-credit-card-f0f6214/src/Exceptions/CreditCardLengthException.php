<?php

namespace LVR\CreditCard\Exceptions;

class CreditCardLengthException extends CreditCardException
{
}
