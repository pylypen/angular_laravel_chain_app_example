<?php

namespace LVR\CreditCard\Contracts;

interface CreditCard
{
}
