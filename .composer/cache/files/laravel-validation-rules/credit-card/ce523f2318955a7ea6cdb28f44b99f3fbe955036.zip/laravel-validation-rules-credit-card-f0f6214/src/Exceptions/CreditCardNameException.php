<?php

namespace LVR\CreditCard\Exceptions;

class CreditCardNameException extends CreditCardException
{
}
