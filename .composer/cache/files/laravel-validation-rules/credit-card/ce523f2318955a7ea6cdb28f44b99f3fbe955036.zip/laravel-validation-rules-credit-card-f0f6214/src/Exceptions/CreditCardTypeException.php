<?php

namespace LVR\CreditCard\Exceptions;

class CreditCardTypeException extends CreditCardException
{
}
