<?php

namespace LVR\CreditCard\Exceptions;

class CreditCardException extends \Exception
{
}
