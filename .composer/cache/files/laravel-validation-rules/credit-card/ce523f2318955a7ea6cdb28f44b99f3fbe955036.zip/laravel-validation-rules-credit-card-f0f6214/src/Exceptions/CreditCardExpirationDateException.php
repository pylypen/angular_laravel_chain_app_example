<?php

namespace LVR\CreditCard\Exceptions;

class CreditCardExpirationDateException extends CreditCardException
{
}
