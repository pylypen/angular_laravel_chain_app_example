<?php

namespace LVR\CreditCard\Exceptions;

class CreditCardCharactersException extends CreditCardException
{
}
