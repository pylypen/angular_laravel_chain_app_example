<?php

namespace LVR\CreditCard\Exceptions;

class CreditCardPatternException extends CreditCardException
{
}
