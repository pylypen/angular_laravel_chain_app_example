<?php

namespace LVR\CreditCard\Exceptions;

class CreditCardCvcException extends CreditCardException
{
}
